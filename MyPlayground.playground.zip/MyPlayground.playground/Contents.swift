import UIKit

var str = "Hello Class!"

let a = 100

if a < 100{
    print ("a is less than 100")
}
else if a > 100{
    print("a greater than 100")
}
else{
    print("a is equal to 100")
}

for counter in 1...10{
    print("Hello")
}




